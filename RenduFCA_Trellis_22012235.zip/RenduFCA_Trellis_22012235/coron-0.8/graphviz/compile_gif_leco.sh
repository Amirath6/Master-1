#!/bin/bash

dot -Tgif lattice.dot -o lattice.gif
