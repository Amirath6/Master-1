#!/bin/bash

dot -Tgif eq_classes.dot -o eq_classes.gif
