#!/usr/bin/bash

\rm ./*.dot ./*.gif
