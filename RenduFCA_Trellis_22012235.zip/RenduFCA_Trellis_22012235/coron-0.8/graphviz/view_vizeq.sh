#!/bin/bash

gqview eq_classes.gif &
